# Backend Environment Variables

# Server Configuration
PORT=5000
NODE_ENV=development

# Google Sheets Configuration
GOOGLE_SHEET_ID=your_spreadsheet_id_here

# Example: 1DYV-6zG0ZAYi3NDUl4R_example_sheet_id

# Note: Place your service-account-key.json file in the same directory as server.js
# Get it from Google Cloud Console > IAM & Admin > Service Accounts