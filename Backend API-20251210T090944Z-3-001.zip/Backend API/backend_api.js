// server.js - Backend API Server for DB-Hotel-UP
const express = require('express');
const cors = require('cors');
const { google } = require('googleapis');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// Google Sheets Configuration
const SPREADSHEET_ID = process.env.GOOGLE_SHEET_ID;
const SCOPES = ['https://www.googleapis.com/auth/spreadsheets'];

// Initialize Google Sheets API with Service Account
const auth = new google.auth.GoogleAuth({
  keyFile: './service-account-key.json', // Path to your service account key
  scopes: SCOPES,
});

const sheets = google.sheets({ version: 'v4', auth });

// Helper function to convert sheet data to objects
function sheetToObjects(headers, rows) {
  return rows.map(row => {
    const obj = {};
    headers.forEach((header, index) => {
      obj[header] = row[index] || '';
    });
    return obj;
  });
}

// Helper function to append row to sheet
async function appendToSheet(range, values) {
  try {
    const response = await sheets.spreadsheets.values.append({
      spreadsheetId: SPREADSHEET_ID,
      range: range,
      valueInputOption: 'USER_ENTERED',
      resource: { values: [values] },
    });
    return response.data;
  } catch (error) {
    console.error('Error appending to sheet:', error);
    throw error;
  }
}

// Helper function to update row in sheet
async function updateSheet(range, values) {
  try {
    const response = await sheets.spreadsheets.values.update({
      spreadsheetId: SPREADSHEET_ID,
      range: range,
      valueInputOption: 'USER_ENTERED',
      resource: { values: [values] },
    });
    return response.data;
  } catch (error) {
    console.error('Error updating sheet:', error);
    throw error;
  }
}

// ==================== ROOMS API ====================

// GET /api/rooms - Fetch all rooms
app.get('/api/rooms', async (req, res) => {
  try {
    const response = await sheets.spreadsheets.values.get({
      spreadsheetId: SPREADSHEET_ID,
      range: '1-2 ห้อง!A:H', // Adjust range based on your sheet
    });

    const rows = response.data.values;
    if (!rows || rows.length === 0) {
      return res.json([]);
    }

    const headers = rows[0];
    const dataRows = rows.slice(1);
    const rooms = sheetToObjects(headers, dataRows);

    res.json(rooms);
  } catch (error) {
    console.error('Error fetching rooms:', error);
    res.status(500).json({ error: 'Failed to fetch rooms' });
  }
});

// PUT /api/rooms/:id/status - Update room status
app.put('/api/rooms/:id/status', async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    // First, find the row index for this room
    const response = await sheets.spreadsheets.values.get({
      spreadsheetId: SPREADSHEET_ID,
      range: '1-2 ห้อง!A:A',
    });

    const roomIds = response.data.values.flat();
    const rowIndex = roomIds.findIndex(roomId => roomId === id);

    if (rowIndex === -1) {
      return res.status(404).json({ error: 'Room not found' });
    }

    // Update the status column (assuming column F is status)
    await updateSheet(`1-2 ห้อง!F${rowIndex + 1}`, [status]);

    res.json({ success: true, room_id: id, new_status: status });
  } catch (error) {
    console.error('Error updating room status:', error);
    res.status(500).json({ error: 'Failed to update room status' });
  }
});

// ==================== CUSTOMERS API ====================

// GET /api/customers - Fetch all customers
app.get('/api/customers', async (req, res) => {
  try {
    const response = await sheets.spreadsheets.values.get({
      spreadsheetId: SPREADSHEET_ID,
      range: '2-1 ลูกค้า!A:I',
    });

    const rows = response.data.values;
    if (!rows || rows.length === 0) {
      return res.json([]);
    }

    const headers = rows[0];
    const dataRows = rows.slice(1);
    const customers = sheetToObjects(headers, dataRows);

    res.json(customers);
  } catch (error) {
    console.error('Error fetching customers:', error);
    res.status(500).json({ error: 'Failed to fetch customers' });
  }
});

// POST /api/customers - Add new customer
app.post('/api/customers', async (req, res) => {
  try {
    const customer = req.body;
    
    // Generate customer ID
    const customerId = `CM${Math.floor(Math.random() * 10000)}`;
    
    const values = [
      customerId,
      customer.name,
      customer.phone,
      customer.email || '',
      customer.id_card || '',
      customer.passport || '',
      customer.customer_type,
      customer.date_of_birth || '',
      customer.notes || '',
    ];

    await appendToSheet('2-1 ลูกค้า!A:I', values);

    res.json({ success: true, customer_id: customerId, ...customer });
  } catch (error) {
    console.error('Error adding customer:', error);
    res.status(500).json({ error: 'Failed to add customer' });
  }
});

// ==================== BOOKINGS API ====================

// GET /api/bookings - Fetch all bookings
app.get('/api/bookings', async (req, res) => {
  try {
    const response = await sheets.spreadsheets.values.get({
      spreadsheetId: SPREADSHEET_ID,
      range: '2-2 จองห้อง/เข้าพัก!A:I',
    });

    const rows = response.data.values;
    if (!rows || rows.length === 0) {
      return res.json([]);
    }

    const headers = rows[0];
    const dataRows = rows.slice(1);
    const bookings = sheetToObjects(headers, dataRows);

    res.json(bookings);
  } catch (error) {
    console.error('Error fetching bookings:', error);
    res.status(500).json({ error: 'Failed to fetch bookings' });
  }
});

// POST /api/bookings - Create new booking
app.post('/api/bookings', async (req, res) => {
  try {
    const booking = req.body;
    
    // Generate booking ID
    const bookingId = `VP${Math.floor(Math.random() * 100000)}`;
    
    const values = [
      bookingId,
      booking.customer_id,
      booking.room_id,
      booking.check_in_date,
      booking.check_out_date,
      booking.total_amount,
      booking.status,
      booking.payment_status,
      booking.channel,
    ];

    await appendToSheet('2-2 จองห้อง/เข้าพัก!A:I', values);

    res.json({ success: true, booking_id: bookingId, ...booking });
  } catch (error) {
    console.error('Error creating booking:', error);
    res.status(500).json({ error: 'Failed to create booking' });
  }
});

// PUT /api/bookings/:id/status - Update booking status
app.put('/api/bookings/:id/status', async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    // Find the row index for this booking
    const response = await sheets.spreadsheets.values.get({
      spreadsheetId: SPREADSHEET_ID,
      range: '2-2 จองห้อง/เข้าพัก!A:A',
    });

    const bookingIds = response.data.values.flat();
    const rowIndex = bookingIds.findIndex(bookingId => bookingId === id);

    if (rowIndex === -1) {
      return res.status(404).json({ error: 'Booking not found' });
    }

    // Update the status column (assuming column G is status)
    await updateSheet(`2-2 จองห้อง/เข้าพัก!G${rowIndex + 1}`, [status]);

    res.json({ success: true, booking_id: id, new_status: status });
  } catch (error) {
    console.error('Error updating booking status:', error);
    res.status(500).json({ error: 'Failed to update booking status' });
  }
});

// ==================== EXPENSES API ====================

// GET /api/expenses - Fetch all expenses
app.get('/api/expenses', async (req, res) => {
  try {
    const response = await sheets.spreadsheets.values.get({
      spreadsheetId: SPREADSHEET_ID,
      range: '2-4 รายจ่าย!A:F',
    });

    const rows = response.data.values;
    if (!rows || rows.length === 0) {
      return res.json([]);
    }

    const headers = rows[0];
    const dataRows = rows.slice(1);
    const expenses = sheetToObjects(headers, dataRows);

    res.json(expenses);
  } catch (error) {
    console.error('Error fetching expenses:', error);
    res.status(500).json({ error: 'Failed to fetch expenses' });
  }
});

// ==================== SETTINGS API ====================

// GET /api/settings - Fetch all settings
app.get('/api/settings', async (req, res) => {
  try {
    const response = await sheets.spreadsheets.values.get({
      spreadsheetId: SPREADSHEET_ID,
      range: '1-1 ตั้งค่า!A:D',
    });

    const rows = response.data.values;
    if (!rows || rows.length === 0) {
      return res.json([]);
    }

    const headers = rows[0];
    const dataRows = rows.slice(1);
    const settings = sheetToObjects(headers, dataRows);

    res.json(settings);
  } catch (error) {
    console.error('Error fetching settings:', error);
    res.status(500).json({ error: 'Failed to fetch settings' });
  }
});

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ status: 'healthy', timestamp: new Date().toISOString() });
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
  console.log(`📊 Connected to Google Sheet: ${SPREADSHEET_ID}`);
});