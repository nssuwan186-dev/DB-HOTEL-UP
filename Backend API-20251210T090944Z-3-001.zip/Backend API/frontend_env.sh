# Frontend Environment Variables

# Backend API URL
VITE_API_URL=http://localhost:5000/api

# Gemini API Key (for AI Assistant)
GEMINI_API_KEY=your_gemini_api_key_here

# Production URL (when deploying)
# VITE_API_URL=https://your-production-api.com/api