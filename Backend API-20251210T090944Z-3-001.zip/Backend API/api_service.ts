// api.ts - API Service for communicating with Backend
import { Room, RoomStatus, Customer, Booking, BookingStatus, Expense, HotelSetting } from './types';

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

// Generic fetch wrapper with error handling
async function apiFetch<T>(endpoint: string, options?: RequestInit): Promise<T> {
  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      headers: {
        'Content-Type': 'application/json',
        ...options?.headers,
      },
      ...options,
    });

    if (!response.ok) {
      throw new Error(`API Error: ${response.statusText}`);
    }

    return await response.json();
  } catch (error) {
    console.error('API Fetch Error:', error);
    throw error;
  }
}

// ==================== ROOMS API ====================

export const roomsAPI = {
  // Fetch all rooms
  getAll: async (): Promise<Room[]> => {
    return apiFetch<Room[]>('/rooms');
  },

  // Update room status
  updateStatus: async (roomId: string, status: RoomStatus): Promise<{ success: boolean }> => {
    return apiFetch(`/rooms/${roomId}/status`, {
      method: 'PUT',
      body: JSON.stringify({ status }),
    });
  },
};

// ==================== CUSTOMERS API ====================

export const customersAPI = {
  // Fetch all customers
  getAll: async (): Promise<Customer[]> => {
    return apiFetch<Customer[]>('/customers');
  },

  // Add new customer
  create: async (customerData: Omit<Customer, 'customer_id'>): Promise<Customer> => {
    return apiFetch<Customer>('/customers', {
      method: 'POST',
      body: JSON.stringify(customerData),
    });
  },
};

// ==================== BOOKINGS API ====================

export const bookingsAPI = {
  // Fetch all bookings
  getAll: async (): Promise<Booking[]> => {
    return apiFetch<Booking[]>('/bookings');
  },

  // Create new booking
  create: async (bookingData: Omit<Booking, 'booking_id'>): Promise<Booking> => {
    return apiFetch<Booking>('/bookings', {
      method: 'POST',
      body: JSON.stringify(bookingData),
    });
  },

  // Update booking status
  updateStatus: async (bookingId: string, status: BookingStatus): Promise<{ success: boolean }> => {
    return apiFetch(`/bookings/${bookingId}/status`, {
      method: 'PUT',
      body: JSON.stringify({ status }),
    });
  },
};

// ==================== EXPENSES API ====================

export const expensesAPI = {
  // Fetch all expenses
  getAll: async (): Promise<Expense[]> => {
    return apiFetch<Expense[]>('/expenses');
  },
};

// ==================== SETTINGS API ====================

export const settingsAPI = {
  // Fetch all settings
  getAll: async (): Promise<HotelSetting[]> => {
    return apiFetch<HotelSetting[]>('/settings');
  },
};

// ==================== HEALTH CHECK ====================

export const healthCheck = async (): Promise<{ status: string; timestamp: string }> => {
  return fetch(`${API_BASE_URL.replace('/api', '')}/health`).then(r => r.json());
};